package com.example.login_registrationappforfuelstation_usingsqlitedb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class StationOwnerRegistration extends AppCompatActivity {

    EditText stationName,stationNo,username,password,repassword;
    ImageView showHidePwd1,showHidePwd2;
    Button signup,signin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_station_owner_registration);

        stationName=findViewById(R.id.stationName);
        stationNo=findViewById(R.id.stationNo);
        username=findViewById(R.id.username);
        password=findViewById(R.id.ownerPassword);
        repassword=findViewById(R.id.ownerRepassword);
//        showHidePwd1=findViewById(R.id.imageview_show_hide_pwd1);
//        showHidePwd2=findViewById(R.id.imageview_show_hide_pwd2);
        signin=findViewById(R.id.signin);
        signup=findViewById(R.id.signup);


//        showHidePwd1.setImageResource(R.drawable.actionhidepassword);
//        showHidePwd2.setImageResource(R.drawable.actionhidepassword);
        DB = new DBHelper(this);




       /* showHidePwd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance()))
                {
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    showHidePwd1.setImageResource(R.drawable.actionhidepassword);
                }
                else
                {
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    showHidePwd1.setImageResource(R.drawable.actionshowpassword);
                }
            }
        });
*/
        /*showHidePwd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(repassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance()))
                {
                    repassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    showHidePwd2.setImageResource(R.drawable.actionhidepassword);
                }
                else
                {
                    repassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    showHidePwd2.setImageResource(R.drawable.actionshowpassword);
                }
            }
        });*/

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name=stationName.getText().toString();
                String no=stationNo.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();

                String email = username.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if (email.matches(emailPattern))
                {
                    Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(name) || TextUtils.isEmpty(no)||TextUtils.isEmpty(user) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass))
                    Toast.makeText(StationOwnerRegistration.this,"All fields are required",Toast.LENGTH_SHORT).show();
                else
                if(pass.equals(repass)){
                    Boolean CheckUser = DB.checkUsername(user);
                    if(CheckUser==false){


                        // call rest api here
                        try {

                            //ChangeThisURL
                            String url = "https://dev-sliit-api.azurewebsites.net/api/Station";
                            JSONObject js = new JSONObject();
                            try {
                                js.put("stationName", name);
                                js.put("stationNo", no);
                                js.put("stationOwnerName", user);
                                js.put("stationOwnerEmail", email);
                                js.put("password", pass);
                                js.put("confirmPassword", repass);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                System.out.println(e.toString());
                            }
                            // Make request for JSONObject
                            JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                                    Request.Method.POST, url, js,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            //Only on sucess response from API we save the owner to SQL Light DB

                                            Boolean insert = DB.insertData(user,pass);
                                            if(insert==true){
                                                Toast.makeText(StationOwnerRegistration.this,"Registered Successfully..",Toast.LENGTH_SHORT).show();
                                                Intent intent = new Intent(getApplicationContext(),FuelStationHomeActivity.class);
                                                startActivity(intent);
                                            }
                                            else{
                                                Toast.makeText(StationOwnerRegistration.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    System.out.println(error.toString());
                                    Log.d("JsonObjectRequest", "Error: " + error.getMessage());
                                }
                            }) {
                                @Override
                                public Map<String, String> getHeaders() throws AuthFailureError {
                                    HashMap<String, String> headers = new HashMap<String, String>();
                                    headers.put("Content-Type", "application/json; charset=utf-8");
                                    return headers;
                                }
                            };

                            Volley.newRequestQueue(getApplicationContext()).add(jsonObjReq);
                        } catch (Exception e) {
                            Log.e("JSONPost", e.getMessage());
                            Toast.makeText(StationOwnerRegistration.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }
                    else{
                        Toast.makeText(StationOwnerRegistration.this, "User Already Exists", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(StationOwnerRegistration.this, "Passwords are not matching", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),StationOwnerLoginActivity.class);
                startActivity(intent);
            }
        });

    }
}