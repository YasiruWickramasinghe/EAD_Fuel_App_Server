package com.example.login_registrationappforfuelstation_usingsqlitedb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class UserRegistration extends AppCompatActivity {

    EditText username, password, repassword, chassisNo;
    Button signup, signin;
    Spinner vehicleType;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        repassword = findViewById(R.id.repassword);
        chassisNo = findViewById(R.id.chassisNo);
        signup = findViewById(R.id.signup);
        signin = findViewById(R.id.signin);
        vehicleType = findViewById(R.id.spinner);

        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names));
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        vehicleType.setAdapter(typeAdapter);

        DB = new DBHelper(this);


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();
                String chassis = chassisNo.getText().toString();
                String type = "CAR";

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass) || TextUtils.isEmpty(chassis))
                    Toast.makeText(UserRegistration.this, "All fields are required", Toast.LENGTH_SHORT).show();
                else if (pass.equals(repass)) {
                    Boolean CheckUser = DB.checkUsername(user);
                    if (CheckUser == false) {

                        // call rest api here
                        try {

                            //ChangeThisURL
                            String url = "https://dev-sliit-api.azurewebsites.net/api/Vehicle";
                            JSONObject js = new JSONObject();
                            try {
                                js.put("vehicleNo", user);
                                js.put("vehicleType", type);
                                js.put("chassisNo", chassis);
                                js.put("password", pass);
                                js.put("confirmPassword", repass);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                System.out.println(e.toString());
                            }
                            // Make request for JSONObject
                            JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                                    Request.Method.POST, url, js,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            //Only on sucess response from API we save the vehicle to SQL Light DB
                                            Boolean insert = DB.insertData(user, pass);
                                            if (insert == true) {
                                                Toast.makeText(UserRegistration.this, "Registered Successfully..", Toast.LENGTH_SHORT).show();
                                                Intent intent = new Intent(getApplicationContext(), FuelStationHomeActivity.class);
                                                startActivity(intent);
                                            } else {
                                                Toast.makeText(UserRegistration.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    System.out.println(error.toString());
                                    Log.d("JsonObjectRequest", "Error: " + error.getMessage());
                                }
                            }) {
                                @Override
                                public Map<String, String> getHeaders() throws AuthFailureError {
                                    HashMap<String, String> headers = new HashMap<String, String>();
                                    headers.put("Content-Type", "application/json; charset=utf-8");
                                    return headers;
                                }
                            };

                            Volley.newRequestQueue(getApplicationContext()).add(jsonObjReq);
                        } catch (Exception e) {
                            Log.e("JSONPost", e.getMessage());
                            Toast.makeText(UserRegistration.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }

                    } else {
                        Toast.makeText(UserRegistration.this, "User Already Exists", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(UserRegistration.this, "Passwords are not matching", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }


}


